# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fred_employment_info']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'fred-employment-info',
    'version': '0.1.0',
    'description': 'It is a python package that can collect employment information from FRED API.',
    'long_description': None,
    'author': 'JinghanMa98',
    'author_email': 'jm5223@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
